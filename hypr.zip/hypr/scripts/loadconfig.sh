#!/bin/bash
hyprctl reload
